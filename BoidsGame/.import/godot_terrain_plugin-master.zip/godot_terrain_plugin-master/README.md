# Basic terrain plugin for Godot 3.1
Realy basic plugin right now. You probably should use something else :)
![Grass](https://raw.githubusercontent.com/wojtekpil/godot_grass_plugin/master/fur.png)
Please watch video tutorial at https://www.youtube.com/watch?v=GLtdy3jiAp0
